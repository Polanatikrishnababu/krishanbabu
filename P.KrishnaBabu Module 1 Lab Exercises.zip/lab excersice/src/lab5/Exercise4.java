package lab5;
import java.util.Scanner;


public class Exercise4 {
public static void main(String args[])
{
	Scanner sc= new Scanner(System.in);
	String fn=null;
	String ln=null;
	sc.close();
	try
	{
		if(fn==null || ln==null)
			System.out.println("First name and Last name should not be blank!!");
		else 
			System.out.println("firstname:  "+fn+ "lastname" +ln);
	}
	catch(Exception e)
	{
		System.out.println(e);
	}

	
}

}
