package Lab10;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.*;
class CopyDataThread extends Thread{
	FileInputStream kbok;
	FileOutputStream  kbkk;
	
	
	public CopyDataThread(FileInputStream kbok,FileOutputStream  kbkk) {
		this.kbok=kbok;
		this.kbkk=kbkk;
		
	}
	public void run() {
		try {
			int a,i=0;
			while( (a=kbok.read())!= -1){
				kbkk.write(a);
				i++;
				if(i%10==0)
				{
					System.out.println("10 character are copied");
					
				}
				try {
					sleep(10000);
					
				}catch(InterruptedException e) {
					System.out.println("This should not come");
				}
			}
		
	kbok.close();
	kbkk.close();
	System.out.println("Copy Successful");
	}
	catch(IOException e)
	{
		System.out.println(e);
	}
}


}

	
