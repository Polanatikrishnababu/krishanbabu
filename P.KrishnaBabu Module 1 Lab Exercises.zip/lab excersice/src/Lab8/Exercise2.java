package Lab8;
import java.util.*;
import java.io.*;


import java.io.*;
public class Exercise2 {
	public void readRAF()throws IOException{
		try {
			RandomAccessFile kbObj=new RandomAccessFile("C:\\krishna/krishna.txt","r");
			String b;
			while((b=kbObj.readLine())!=null) {
				System.out.println(b);
				
			}
			kbObj.close();
			
		}
		catch (Exception e)
		{
			System.out.println(e);
			

			}
	}

	
public static  void main(String args[]) throws IOException
{
	Exercise2 kb= new Exercise2();
	kb.readRAF();
}
}

	

	

	



	

		




