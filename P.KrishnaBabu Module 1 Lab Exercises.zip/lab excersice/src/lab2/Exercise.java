package lab2;
import java.util.Scanner;
abstract class Item{
	private int Identificationnumber()
	{
		return Identificationnumber();
		
	}

private char title() {
return title();
}

private int Nofcopies() {
	return Nofcopies();
	
}
}
class WrittenItem extends Item{
	private char author()
	{
		return author();
		
	}
}
	class Book extends WrittenItem{
		
	}
	class Journalpaper extends WrittenItem{
		private int Year()
		{
			return Year();
			
		}
	}

			
class  MediaItem extends Item{
	private int runtime()
	{
		return runtime();
		
	}
}
class Video extends MediaItem{
				private char director()
				{
					return director();
				}
				private char genre() {
					return genre();
					
				}
				private int year()
				{
					return year();
					
				}

			}
class CD extends MediaItem{
	private char artist() {
		return artist();
	}
	private char genre() {
		return genre();
		
	}
}


public class Exercise {
	public static void main(String args[]) {
		
	}
}




