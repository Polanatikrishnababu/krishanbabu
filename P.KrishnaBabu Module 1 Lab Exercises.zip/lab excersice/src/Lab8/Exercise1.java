package Lab8;
import java.util.*;


public class Exercise1 {
public static void main(String args[]) {
	Scanner sc=new Scanner(System.in);
	String str=sc.nextLine();
	StringTokenizer st= new StringTokenizer(str);
	int sum=0;
	while(st.hasMoreTokens())
	{ sum= sum+Integer.parseInt(st.nextToken());
	}
	System.out.println("sum is :"+sum);
	sc.close();
	}

}

