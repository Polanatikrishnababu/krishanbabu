package lab1;
import java.util.*;


class CalculateSum
{
	void calculateSum (int b)
	
	{ 
	 int i;
	 int sum =0;
	 for(i=1;i<=b;i++)
		 
	 {
		 if(i%3==0||i%5==0)
		 {
			 sum =sum+i;
		 }
	 }
		 
		System.out.println(sum);
		
	
		
	}
}
public class excercise1 {
	public static void main(String args[]) {
		Scanner krishna = new  Scanner(System.in);
		int p =krishna.nextInt();
		CalculateSum pavan = new CalculateSum();
		pavan.calculateSum(p);
	}

	}
