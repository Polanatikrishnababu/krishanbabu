package lab3;
import java.util.Arrays;
class Sort {
int [] getSorted(int a[])
{
	int length=a.length;
	int b[]= new int [length];
	int j=0;
	int temp;
	for(int c=a.length-1;c>=0;c--) {
		b[j]=a[c];
		j++;
		
	}
	for( int p=0;p<length;p++)
	{
		for(int q=p+1;q<length;q++)
		{
			if (b[p]>b[q])
			{
				temp=b[p];
				b[p]=b[q];
				b[q]=temp;
				
			}
		}
	}
	return b;
}
}
public class Exercise3 {
public static void main(String args[]) {
	 int a[]=new int[5];
	 int c[]=new int[5];
	 a[0]=8;
	  a[1]=6;
	 a[2]=7;
	 a[3]=9;
	 a[4]=7;
	 Sort s=new Sort();
	 c=s.getSorted(a);
	 System.out.println(Arrays.toString(c));
	 
	 
}
}
