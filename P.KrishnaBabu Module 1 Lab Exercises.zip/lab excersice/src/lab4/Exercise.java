package lab4;
import java.util.*;

class Arm
{
	int arm (int n)
	{
		int sum=0;
		for(int i=1;i<=n;i++)
		{
			int rem=n%10;
			sum= sum+(rem*rem*rem);
			n=n/10;
		}
		return sum;
	}
}
public class Exercise {
public static void main(String[]args) {
	Scanner sc= new Scanner(System.in);
	int a=sc.nextInt();
	int b=a;
	Arm kb= new Arm();
	int result =kb.arm(b);
	System.out.println(result);
	
	
	
}
}
