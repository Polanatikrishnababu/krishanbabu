package Lab8;
import java.util.Scanner;
public class Exercise3 {
	public void counting(String str)
	{
		int i=0,c=0,words=0,lines=1;
		str=str+' ';
		char ch[] = str.toCharArray();
		int len =ch.length;
		for(i=0;i<len;i++)
		{
			char chr =ch[i];
			char b=ch[i+1];
			if((chr >=65 &&  chr<= 90) || (chr>= 97&& chr <= 122))
				c++;
			if (b==' '&& chr !=' ')
				 words++;
			if((chr =='\n'))
				lines++;
             
		}
				System.out.println("Characters: " +(len-1)+"\nWords: " +words+"\nLines:" +lines);
	}
	public static void main(String args[])
	{
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter string");
		String str =sc.nextLine();
		Exercise3 obj = new Exercise3();
		obj.counting(str);
		sc.close();
		
	}

}
