package Lab10;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class FileProgram {
	public static void main(String args[])
	{
		try {
			FileInputStream kbok=new FileInputStream("C:\\krishna/krishna.txt");
			FileOutputStream kbkk=new FileOutputStream("C:\\krishna\\pavan.txt");
			CopyDataThread cdy= new CopyDataThread(kbok,kbkk);
			cdy.start();
		}
	catch( Exception e)
		{
		System.out.println(e);
		
		}
		
	}
		

}
