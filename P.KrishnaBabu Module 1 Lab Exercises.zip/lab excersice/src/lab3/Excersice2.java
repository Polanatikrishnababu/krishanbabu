package lab3;
import java.util.Scanner;
import java.util.*;
class Alphabet{
	int i=0;
	public void alpha(String[] arr)
	{
		int length = arr.length;
		Arrays.sort(arr);
		System.out.println(Arrays.toString(arr));
		if (length%2!=0) {
			for(int i=0; i<(length/2)+1;i++) {
				arr[i]=arr[i].toUpperCase();
		}
		for(int i=(length/2)+1; i<length;i++) {
			arr[i] = arr[i].toLowerCase();
		
		}
		}
		else 
		{
			for(int i=0; i<(length/2)+1;i++) {
				arr[i]=arr[i].toUpperCase();
		}
		for(int i=(length/2); i<length;i++) {
			arr[i] = arr[i].toLowerCase();
		
		}
		}
				
	System.out.println(Arrays.toString(arr));
	}
}
public class Excersice2 {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		Alphabet alphabetObj = new Alphabet();
		System.out.println("Enter the number of elements");
		int elements =sc.nextInt();
		String arr[] = new String [elements];
		System.out.println("Enter the elements");
		for(int i=0; i<elements;i++)
		arr[i]= sc.next().toLowerCase();
		alphabetObj.alpha(arr);
		sc.close();
	}

		
		
	
	


}

