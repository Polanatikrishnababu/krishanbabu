package lab3;
import java.util.Scanner;


public class EXercise4 {
	public static void main(String args[])
	{
		Scanner sc= new Scanner(System.in);
		char ch[]=new char[10];
		System.out.println("Enter the String : ");
		ch=sc.next().toCharArray();
		int len=ch.length;
		int count=0;
		int flag=0;
		for(int i=0;i<len;i++)
		{
			count=0;
			for(int j=0;j<len;j++)
			{
				if(ch[j]==ch[i])
				
					count++;
					for(int k=0;k<i;k++)
					{
						if(ch[k]==ch[i])
							flag=1;
					}
			}
						if(flag==0)
							System.out.println(ch[i]+":"+count);
						
					}
				
					
					
				}
			}
	

