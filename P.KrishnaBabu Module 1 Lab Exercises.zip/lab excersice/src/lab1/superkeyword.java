package lab1;

class Base {
	int a=90;
	Base (int a){
		System.out.println("Base:"+this.a);
	}
}
class sub extends Base{
	int a=67;
	sub(){
		super(22);
		int a=88;
		System.out.println("Sub super:"+super.a);
		System.out.println("Sub this:"+this.a);
		System.out.println("Sub a:"+a);
		
		
		
	}
}
public class superkeyword {
	public static void main(String args[])
	{
		sub s=new sub();
		
	}
}
