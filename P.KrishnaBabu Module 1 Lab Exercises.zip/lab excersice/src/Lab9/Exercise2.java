package Lab9;
import java.util.*;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.Collections;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class Exercise2 {
 HashMap countCharacter(char[] ch) {
	 HashMap<Character,Integer> a= new HashMap<Character,Integer>();
	 int length =ch.length;
	 int count =0,flag=0;
	 for(int i=0;i<length;i++)
	 {
		 count=0;
		 for(int j=0;j<length;j++)
		 
			 if (ch[j]==ch[i])
			 
				 count++;
				 
			 
			 for(int k=0;k<i;k++)
			 
				 if(ch[k]==ch[i])
				 
					 flag=1;
					 flag=0;
					 a.put(ch[i], count);
					 
				 
		 }
			 return a;
			 
		 }
 
	
 
 
		 public static void main(String args[])
		 
		 { System.out.println("Enter the String");
			 Scanner sc=new Scanner(System.in);
			 char ch[]=new char[50];
			 ch=sc.next().toCharArray();
			 Exercise2 e= new Exercise2();
			 HashMap<Character,Integer> h =new HashMap<Character,Integer>();
			 h=e.countCharacter(ch);
			 for(Map.Entry mp:h.entrySet())
			 {
				 char key =(char)mp.getKey();
				 Integer count =(Integer)mp.getValue();
				 System.out.println(key +":"+count);
				 
				 }
			 
		 }
 }
	

 

