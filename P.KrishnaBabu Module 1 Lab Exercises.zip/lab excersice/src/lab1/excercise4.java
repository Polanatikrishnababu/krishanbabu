package lab1;
import java.util.Scanner;


public class excercise4 {
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		int l=sc.nextInt();
		if(checkNumber(l))
			System.out.println(l+" is power of 2");
		else 
			System.out.println(l+" is not  power of 2");
		
	}
 static boolean checkNumber(int k)
 {
	 while(k>1) {
		 if(k%2!=0)
		 {return false;
		 
		 }
		 k=k/2;
		 
	 }
	 return true;
 }
}
