package Lab13;
import java.util.*;

import Lab13.Employee.EmployeeDetails;


public class Exercise4 
{
	public static void main(String [] args)
	{
		EmployeeDetails e = Employee :: new;
		Employee  ed = e.getEmployee("hello",1);
		System.out.println("Employee Name: "+ed.getName());
		System.out.println("Employee ID : "+ed.getEmid());
	}
	
}


class Employee
{
	String name;
	int emid;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getEmid() {
		return emid;
	}
	public void setEmid(int emid) {
		this.emid = emid;
	}
	public Employee(String name,int emid)
	{
		this.name=name;
		this.emid=emid; 
	}
	interface EmployeeDetails{
		public Employee getEmployee(String name, Integer emid);
	}
}
