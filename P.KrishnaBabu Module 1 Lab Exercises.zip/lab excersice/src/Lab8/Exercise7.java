package Lab8;

public class Exercise7 
{
	public static boolean validate(String name)
	{
		String st  = name.substring(0,name.length()-4);
		if(name.substring(8, name.length()).equals("_job")&&st.length()==8)
		{
			return true;
		}
		else
			return false;
	}
	public static void main(String [] args)
	{
		System.out.print(validate("ysimiley_job"));
	}
}
