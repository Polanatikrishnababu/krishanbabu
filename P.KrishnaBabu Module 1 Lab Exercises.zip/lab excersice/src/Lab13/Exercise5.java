package Lab13;
import java.util.Scanner;
import java.util.*;

public class Exercise5 {
	public static void main(String args[])
	{
		System.out.println("enter the number  ");
		
Scanner sc=new Scanner(System.in);
int n=sc.nextInt();
Factorial f= new Factorial();
Factorial1 fact =  f ::factorial;
int result = fact.fact(n);
System.out.println("factorial of the number = "+result);

}
}
class Factorial
{
	int factorial(int a)
	{
		int fact=1;
		for(int i=1;i<=a;i++)
		{
			fact = fact*i;
			
		}
		return fact;
	}

	public int fact(int n) {
		// TODO Auto-generated method stub
		return 0;
	}
}
 interface Factorial1
 {
	 int fact(int x);
 }
 