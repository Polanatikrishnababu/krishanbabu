package lab3;
class Array{
	
	int total=4;
	int getSecondsmallest(int a[])
	{
		int t=0;
		for(int i=0;i<total;i++)
		{
			for(int j=i+1;j<total;j++)
			{
				if(a[i]>a[j])
				{
					t=a[i];
					a[i]=a[j];
					a[j]=t;
				}
					
			}

		}
	
	return a[1];
}
}

public class Excercise1 {
	public static void main(String []args)
	{
		Array pavan= new Array();
		int a[]= {20,30,25,34};
		System.out.println(pavan.getSecondsmallest(a));
	}
	
}

