package lab1;
import java.util.*;

class CalculateDifference 
{
	void calculatedifferece (int n)
	{
		int k=0,b=0;
		int r;
		for(int i=1;i<=n;i++)
		{
			k= k + i*i;
			
		}
		for(int i=1;i<=n;i++)
		{
			b= b + i;
			
		}
		
		b=b*b;
		r=b-k;
		System.out.println(r);
	}
}


public class excercise2 {
	public static void main(String args[]) {
		Scanner krishna = new  Scanner(System.in);
		int p =krishna.nextInt();
		CalculateDifference  q = new CalculateDifference();
		q.calculatedifferece(p);
	}
}


