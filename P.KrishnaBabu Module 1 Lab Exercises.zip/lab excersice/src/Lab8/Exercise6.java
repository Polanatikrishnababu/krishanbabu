package Lab8;
import java.util.*;
import java.time.*;


public class Exercise6 {
	
	void setDate(Date d)
	{
		System.out.println();
		
	}
	public static void main(String args[])
	{
		LocalDate now = LocalDate.now();
		System.out.println("Date:  "+ " "+now  );
	}
	

}
