package lab1;
import java.util.Scanner;


public class excercise3 {
	public static void main(String args[]) {
		System.out.println("enter the number");
		Scanner kb=new Scanner(System.in);
		int number=kb.nextInt();
	
		boolean flag=false;
		int CurrentDigit = number%10;
		{
			number =number/10;
			while(number>10) {
				if(CurrentDigit<=number%10)
					flag = true;
				break;
			}
			CurrentDigit = number%10;
			number = number/10;
			if(flag) 
			{
				System.out.println("not increasing");
				
			
			}
			else {
				System.out.println("increasing");
			}
		}
		
		
	
		
		
		
		
		
	}
	}
