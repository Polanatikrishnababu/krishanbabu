package Lab8;
import java.util.*;
import java.io.*;


public class Exercise4 {
public static void main(String args[])
{
	System.out.println("enter the file address");
	
	Scanner sc= new Scanner(System.in);
	String s= sc.nextLine();
	
	File f= new File("C:\\krishna/krishna.txt");
	System.out.println("File Name: " +f.getName());
	System.out.println("File is readble or not : "+ f.canRead());
	System.out.println("File is writeable or not : "+ f.canWrite());
	System.out.println("File is exists or not: "+f.exists());
	System.out.println("File length in bytes:" +f.length());
	
}
}
